package com.app.exception;

@SuppressWarnings("serial")
public class CustumException extends Exception {
	
	public CustumException(String msg) {
		super(msg);
	}
}
